Tic-Tac-Toe Press Kit - One Day Games

Start here:
1. Open OPEN_PRESS_KIT.html for a self-contained press kit preview. Images are embedded in that file.
2. Use the assets folder for individual PNG downloads.
3. presskit.html is the normal web copy that expects the assets folder beside it.

Live press kit:
https://playonedaygames.com/live/tic-tac-toe/presskit.html

Contact:
play.onedaygames@gmail.com